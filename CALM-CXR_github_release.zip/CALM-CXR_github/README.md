# CALM-CXR

**CALM-CXR** stands for **Calibration-Aware Lung-Masked Chest X-ray classification workflow**.

This repository contains a reproducible PyTorch/Colab workflow for hierarchical chest X-ray classification using lung-mask guidance, two-stage classification, temperature scaling, threshold optimization, hierarchical probability composition, and calibration-aware evaluation.

## Workflow summary

The workflow decomposes a three-class CXR classification task into two binary stages:

1. **Stage-1:** Normal vs. abnormal screening
2. **Stage-2:** Bacterial vs. viral classification among abnormal cases

Final three-class probabilities are composed as:

```text
P(normal)   = P1(normal)
P(bacteria) = P1(abnormal) × P2(bacteria)
P(virus)    = P1(abnormal) × P2(virus)
```

## Repository contents

```text
CALM-CXR/
├── calm_cxr_reproducible.py
├── CALM_CXR_reproducible_colab.ipynb
├── requirements.txt
├── README.md
├── LICENSE
├── CITATION.cff
├── .gitignore
├── configs/
├── docs/
├── figures/
└── outputs/
```

## Dataset organization

Prepare the dataset using class-wise folders:

```text
Lung_data/
├── img/
│   ├── bacteria/
│   ├── normal/
│   └── virus/
├── ASCE_final_processed/
│   ├── bacteria/
│   ├── normal/
│   └── virus/
└── mask/
    ├── bacteria/
    ├── normal/
    └── virus/
```

The code expects image and mask files to share matching filename stems wherever masks are available.

If a mask is missing, the workflow uses an all-ones mask rather than a zero mask to reduce risk of mask-availability leakage.

## Quick start in Google Colab

Mount Google Drive:

```python
from google.colab import drive
drive.mount('/content/drive')
```

Edit the configuration block in the notebook or script:

```python
cfg = Config(
    image_root="/content/drive/MyDrive/Lung_data/ASCE_final_processed",
    mask_root="/content/drive/MyDrive/Lung_data/mask",
    output_dir="/content/drive/MyDrive/calm_cxr_outputs",
    mode="two_stage",
    backbone="convnext_tiny",
    epochs_s1=12,
    epochs_s2=12,
)
```

Run:

```python
metrics = run_two_stage(cfg)
metrics
```

For raw CXR input, change:

```python
image_root="/content/drive/MyDrive/Lung_data/img"
```

## Outputs

The workflow saves:

```text
outputs/
└── two_stage/
    ├── best_stage1.pt
    ├── best_stage2.pt
    ├── two_stage_test_metrics.json
    └── two_stage_test_predictions.npz
```

The JSON file stores the final metrics, stage-wise metrics, thresholds, temperatures, confusion matrix, bootstrap confidence intervals, and error attribution.

The NPZ file stores test labels, predictions, and probability arrays for ROC, PR, and reliability plots.

## Reproducible validation summary

| Input regime | Accuracy | Macro-F1 | ROC-AUC | Macro PR-AUC | ECE | Brier | NLL |
|---|---:|---:|---:|---:|---:|---:|---:|
| Raw CXR | 0.8287 | 0.8354 | 0.9251 | 0.8884 | 0.0458 | 0.2639 | 0.4810 |
| ASCE-enhanced CXR | 0.8406 | 0.8405 | 0.9396 | 0.9144 | 0.0821 | 0.2484 | 0.4797 |

These values are provided for reproducibility documentation. Regenerate them on the target setup before final reporting.

## Important use note

CALM-CXR is a research workflow for reproducible experimentation. It is not an autonomous clinical diagnostic system.

## Citation

Please cite the associated MethodsX protocol article once published. Until then, cite this repository using the metadata in `CITATION.cff`.
