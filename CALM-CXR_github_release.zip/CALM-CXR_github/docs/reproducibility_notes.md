# CALM-CXR reproducibility notes

Recommended reporting:
- State whether the input regime is raw or ASCE-enhanced.
- State the train/validation/calibration/test split strategy.
- Report Stage-1, Stage-2, and final hierarchical metrics separately.
- Report calibration metrics: ECE, Brier score, and NLL.
- Report learned temperatures and optimized thresholds.
- Include hierarchical error attribution.
- Do not use the test set for temperature scaling or threshold tuning.
